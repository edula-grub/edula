<?php

namespace App\Filament\Siswa\Resources\SertifandskilResource\Pages;

use App\Filament\Siswa\Resources\SertifandskilResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSertifandskil extends CreateRecord
{
    protected static string $resource = SertifandskilResource::class;

    protected function getHeaderActions(): array
    {
        return [

        ];
    }
}
